# Made By AsilYup on GitHub! This Project Licensed under _MIT_ License

# ⚠️ Warning:
# This script is designed to send repeated messages automatically.
# Using it to spam others can lead to account bans, legal issues, or other serious consequences.
# Only use it for testing on your own devices and never target other people or platforms without permission.

import pyautogui # type: ignore
import time
import keyboard   # type: ignore

time.sleep(5)
print('Bot is activated. Press "U" to stop.')

while True:
    if keyboard.is_pressed('u'):  
        print("Bot stopped!")
        break
    pyautogui.write('CHANGE THIS')  # <---- CHAHGE THIS TEXT
    pyautogui.press('enter')
    time.sleep(1)